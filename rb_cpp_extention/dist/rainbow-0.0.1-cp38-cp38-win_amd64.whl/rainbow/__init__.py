from rainbow.math import add, sub  # 这里指定rainbow.math就是导入了pyd，而不是math目录；要导入math目录就是.math


__all__ = [
    "add",
    "sub"
]